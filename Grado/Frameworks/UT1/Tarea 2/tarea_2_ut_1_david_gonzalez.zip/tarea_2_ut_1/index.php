<?php
require_once __DIR__ . '/../../vendor/autoload.php';

use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\InterfaceType;
use GraphQL\Type\Schema;
use GraphQL\Server\StandardServer;

// 🎬 Datos de películas
$peliculasData = [
    ['id' => '1', 'titulo' => 'Inception', 'anio' => 2010],
    ['id' => '2', 'titulo' => 'The Matrix', 'anio' => 1999],
    ['id' => '3', 'titulo' => 'Interstellar', 'anio' => 2014]
];

// 📚 Datos de libros y juegos
$authorsData = [
    ['firstName' => 'F. Scott', 'lastName' => 'Fitzgerald'],
    ['firstName' => 'George', 'lastName' => 'Orwell']
];

$publishersData = [
    ['name' => 'Kosmos'],
    ['name' => 'Fantasy Flight']
];

$libItemsData = [
    [
        'id' => '1',
        'title' => 'The Great Gatsby',
        'authors' => [$authorsData[0]]
    ],
    [
        'id' => '2',
        'title' => '1984',
        'authors' => [$authorsData[1]]
    ],
    [
        'id' => '3',
        'title' => 'Catan',
        'pub' => $publishersData[0]
    ],
    [
        'id' => '4',
        'title' => 'Arkham Horror',
        'pub' => $publishersData[1]
    ]
];

// 🧱 Tipos GraphQL
$authorType = new ObjectType([
    'name' => 'Author',
    'fields' => [
        'firstName' => Type::nonNull(Type::string()),
        'lastName' => Type::nonNull(Type::string()),
    ]
]);

$publisherType = new ObjectType([
    'name' => 'Publisher',
    'fields' => [
        'name' => Type::nonNull(Type::string()),
    ]
]);

$libItemInterface = new InterfaceType([
    'name' => 'LibItem',
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
    ],
    'resolveType' => function ($value) use (&$bookType, &$boardGameType) {
        return isset($value['authors']) ? $bookType : $boardGameType;
    }
]);

$bookType = new ObjectType([
    'name' => 'Book',
    'interfaces' => [$libItemInterface],
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
        'authors' => Type::listOf(Type::nonNull($authorType)),
    ]
]);

$boardGameType = new ObjectType([
    'name' => 'BoardGame',
    'interfaces' => [$libItemInterface],
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
        'pub' => Type::nonNull($publisherType),
    ]
]);

$peliculaType = new ObjectType([
    'name' => 'Pelicula',
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'titulo' => Type::nonNull(Type::string()),
        'anio' => Type::nonNull(Type::int())
    ]
]);

$queryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'libItems' => [
            'type' => Type::listOf(Type::nonNull($libItemInterface)),
            'resolve' => function () use ($libItemsData) {
                return $libItemsData;
            }
        ],
        'peliculas' => [
            'type' => Type::listOf(Type::nonNull($peliculaType)),
            'resolve' => function () use ($peliculasData) {
                return $peliculasData;
            }
        ],
        'peliculaPorId' => [
            'type' => $peliculaType,
            'args' => [
                'id' => Type::nonNull(Type::id())
            ],
            'resolve' => function ($root, $args) use ($peliculasData) {
                foreach ($peliculasData as $p) {
                    if ($p['id'] === $args['id']) return $p;
                }
                return null;
            }
        ]
    ]
]);

$schema = new Schema([
    'query' => $queryType,
    'types' => [$bookType, $boardGameType]
]);

$server = new StandardServer([
    'schema' => $schema
]);

try {
    $server->handleRequest();
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}